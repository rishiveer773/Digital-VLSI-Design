
from tabulate import tabulate

file_name = 'W8nmos_ON.txt'

with open(file_name, 'r') as file:
    # Read data line by line and split each line
    data = [line.split() for line in file]

# Display the data in tabulated form
# headers = ["Temp", "M1[W]", "V-sweep", "V(drain)", "V(gate)", "V(source)", "V(body)", "I(Vd)", "I(Vg)", "I(Vs)", "I(Vb)"]
table = tabulate(data,tablefmt="fancy_grid")
print(table)

output_file = 'W8.txt'
with open(output_file, 'w') as output:
    print(table, file=output)