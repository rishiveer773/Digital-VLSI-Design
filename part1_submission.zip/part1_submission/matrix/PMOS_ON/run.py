import subprocess
import pandas as pd
import os

# List of values to iterate over
a_values = [1, 2, 3, 4, 6, 8]

# Iterate over each value of 'a'
for a in a_values:
    # Modify the ngspice code with the current value of 'a'
    with open('pmos_on.spice', 'r') as file:
        ngspice_code = file.read().replace('a*22n', f'{a}*22n')
        ngspice_code = ngspice_code.replace('awpmos_on.txt', f'{a}awpmos_on.txt')
    
    # Ensure ngspice exits automatically after the simulation
    if '.endc' in ngspice_code:
        ngspice_code = ngspice_code.replace('.endc', 'exit\n.endc')
    else:
        ngspice_code += '\nexit\n'

    # Write the modified ngspice code to a file
    with open('pmos_simulation.spice', 'w') as file:
        file.write(ngspice_code)
    
    # Run the ngspice simulation
    subprocess.run(['ngspice', 'pmos_simulation.spice'])

    # Read the output file and store the results
    output_file = f'{a}awpmos_on.txt'
    if os.path.exists(output_file):
        # Assuming the output file has a specific format, let's read it using pandas
        data = pd.read_csv(output_file, delim_whitespace=True)
        data.to_csv(f'{a}awpmos_on.csv', index=False)
        print(f"Results have been saved to '{a}awpmos_on.csv'.")

    print(f'Simulation completed for a = {a}.')

